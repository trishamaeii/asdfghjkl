﻿
Imports MySql.Data.MySqlClient

Module Connection
    Public conn As MySqlConnection
    Public cmd As MySqlCommand
    Sub connect()
        conn = New MySqlConnection()
        Dim db As String = "server=localhost;user id=root;database=ordering_softeng"

        If Not conn Is Nothing Then conn.Close()
        conn.ConnectionString = db
        Try
            conn.Open()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Module

