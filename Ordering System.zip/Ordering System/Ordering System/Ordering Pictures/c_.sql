-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2017 at 07:28 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.5.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `c#`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminmessage`
--

CREATE TABLE `adminmessage` (
  `id` int(100) NOT NULL,
  `Message` varchar(100) DEFAULT NULL,
  `Date` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminmessage`
--

INSERT INTO `adminmessage` (`id`, `Message`, `Date`) VALUES
(1, 'gamy nlang stocks sa humba', '3/26/2017 6:31:05 PM'),
(2, '\nthis my sales', '3/26/2017 6:54:10 PM'),
(3, 'try ', '3/27/2017 12:50:37 PM'),
(4, '', '3/27/2017 12:50:37 PM');

-- --------------------------------------------------------

--
-- Table structure for table `adminss`
--

CREATE TABLE `adminss` (
  `user` varchar(100) NOT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminss`
--

INSERT INTO `adminss` (`user`, `password`) VALUES
('j', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `beef`
--

CREATE TABLE `beef` (
  `id` varchar(100) NOT NULL,
  `FoodName` varchar(100) DEFAULT NULL,
  `Price` varchar(100) DEFAULT NULL,
  `Quantity` varchar(100) DEFAULT NULL,
  `picturename` varchar(100) DEFAULT NULL,
  `Table` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `beef`
--

INSERT INTO `beef` (`id`, `FoodName`, `Price`, `Quantity`, `picturename`, `Table`) VALUES
('1', 'Beef', '250', '744', 'beefbals', 'beef'),
('3', 'Calderetang Baka', '100', '84', 'beefcaldereta', 'beef'),
('4', 'Bulalo', '150', '92', 'bulalo', 'beef'),
('5', 'Beef Stick', '100', '83', 'beefstick', 'beef'),
('6', 'Beef with Vagetables', '85', '30', 'beefvge', 'beef');

-- --------------------------------------------------------

--
-- Table structure for table `cashier`
--

CREATE TABLE `cashier` (
  `user` varchar(100) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `picture` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cashier`
--

INSERT INTO `cashier` (`user`, `password`, `Name`, `picture`) VALUES
('jai', 'jay', 'Peta Tabis', 'pet');

-- --------------------------------------------------------

--
-- Table structure for table `cashierinfo`
--

CREATE TABLE `cashierinfo` (
  `id` int(100) NOT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `mname` varchar(100) DEFAULT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `age` varchar(100) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cashierinfo`
--

INSERT INTO `cashierinfo` (`id`, `fname`, `mname`, `lname`, `age`, `gender`, `address`) VALUES
(1, 'jay Rudy', 'A', 'Arat', '200', 'male', 'butuan City');

-- --------------------------------------------------------

--
-- Table structure for table `cashiermessage`
--

CREATE TABLE `cashiermessage` (
  `id` int(100) NOT NULL,
  `Message` varchar(100) DEFAULT NULL,
  `Date` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cashiermessage`
--

INSERT INTO `cashiermessage` (`id`, `Message`, `Date`) VALUES
(1, 'ghdg', 'sfsfsdgsgs'),
(2, 'eewfwefwefewf', '3/27/2017 12:51:08 PM'),
(3, 'hhhhhh', '3/27/2017 11:52:50 PM');

-- --------------------------------------------------------

--
-- Table structure for table `chicken`
--

CREATE TABLE `chicken` (
  `id` varchar(100) NOT NULL,
  `FoodName` varchar(100) DEFAULT NULL,
  `Price` varchar(100) DEFAULT NULL,
  `Quantity` varchar(100) DEFAULT NULL,
  `picturename` varchar(100) DEFAULT NULL,
  `Table` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chicken`
--

INSERT INTO `chicken` (`id`, `FoodName`, `Price`, `Quantity`, `picturename`, `Table`) VALUES
('1', 'Fried Chicken', '250', '745', 'Fried Chicken', 'chicken'),
('2', 'Lechon Manok', '300', '55', 'lechon', 'chicken'),
('3', 'Chicken Asado', '100', '85', 'asado', 'chicken'),
('4', 'Drum Stick', '150', '92', 'drumstick', 'chicken'),
('5', 'Chicken Vagetables', '100', '83', 'chickenva', 'chicken'),
('6', 'Chicken Balls', '85', '30', 'ChickenAsado', 'chicken');

-- --------------------------------------------------------

--
-- Table structure for table `desert`
--

CREATE TABLE `desert` (
  `id` varchar(100) NOT NULL,
  `FoodName` varchar(100) DEFAULT NULL,
  `Price` varchar(100) DEFAULT NULL,
  `Quantity` varchar(100) DEFAULT NULL,
  `picturename` varchar(100) DEFAULT NULL,
  `Table` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `desert`
--

INSERT INTO `desert` (`id`, `FoodName`, `Price`, `Quantity`, `picturename`, `Table`) VALUES
('1', 'Choco Cake', '100', '745', 'pasayan', 'desert'),
('2', 'Stroberry Cake ', '300', '55', 'stroberry', 'desert'),
('3', 'Cheese Cake', '100', '84', 'cheese', 'desert'),
('4', 'Leche Plan', '100', '92', 'leche', 'desert'),
('5', 'Leche Plan With cheese', '150', '83', 'lec', 'desert'),
('6', 'ChocoLate Cake', '100', '80', 'choc', 'desert');

-- --------------------------------------------------------

--
-- Table structure for table `drinks`
--

CREATE TABLE `drinks` (
  `id` varchar(100) NOT NULL,
  `FoodName` varchar(100) DEFAULT NULL,
  `Price` varchar(100) DEFAULT NULL,
  `Quantity` varchar(100) DEFAULT NULL,
  `picturename` varchar(100) DEFAULT NULL,
  `Table` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `drinks`
--

INSERT INTO `drinks` (`id`, `FoodName`, `Price`, `Quantity`, `picturename`, `Table`) VALUES
('1', 'CocaCola', '30', '742', 'coke', 'drinks'),
('2', 'Orange Juice', '30', '55', 'orange', 'drinks'),
('3', 'Mango', '50', '85', 'mango', 'drinks'),
('4', 'Melon Juice', '150', '90', 'melon', 'drinks');

-- --------------------------------------------------------

--
-- Table structure for table `foodname`
--

CREATE TABLE `foodname` (
  `id` varchar(100) NOT NULL,
  `FoodName` varchar(100) DEFAULT NULL,
  `Price` varchar(100) DEFAULT NULL,
  `Quantity` varchar(100) DEFAULT NULL,
  `PictureName` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `foodname`
--

INSERT INTO `foodname` (`id`, `FoodName`, `Price`, `Quantity`, `PictureName`) VALUES
('1', 'Fried Chicken', '250', '684', 'Fried Chicken'),
('2', 'Beef', '300', '27', 'ChickenAsado'),
('3', 'Vagetables', '100', '73', 'seven'),
('4', 'Pork', '150', '89', 'Pork'),
('5', 'Seafoods', '100', '81', 'kasag');

-- --------------------------------------------------------

--
-- Table structure for table `orderss`
--

CREATE TABLE `orderss` (
  `id` int(100) NOT NULL,
  `FoodName` varchar(100) DEFAULT NULL,
  `Price` varchar(100) DEFAULT NULL,
  `Ouantity` varchar(100) DEFAULT NULL,
  `Total` varchar(100) DEFAULT NULL,
  `Date` varchar(100) DEFAULT NULL,
  `stoks` varchar(100) DEFAULT NULL,
  `Table` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderss`
--

INSERT INTO `orderss` (`id`, `FoodName`, `Price`, `Ouantity`, `Total`, `Date`, `stoks`, `Table`) VALUES
(4, 'Fried Rice', '50', '1', '50', '3/28/2017 12:20:16 PM', '55', 'rice'),
(5, 'Humba', '250', '3', '750', '3/28/2017 12:20:16 PM', '65', 'pork');

-- --------------------------------------------------------

--
-- Table structure for table `pork`
--

CREATE TABLE `pork` (
  `id` varchar(100) NOT NULL,
  `FoodName` varchar(100) DEFAULT NULL,
  `Price` varchar(100) DEFAULT NULL,
  `Quantity` varchar(100) DEFAULT NULL,
  `picturename` varchar(100) DEFAULT NULL,
  `Table` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pork`
--

INSERT INTO `pork` (`id`, `FoodName`, `Price`, `Quantity`, `picturename`, `Table`) VALUES
('1', 'Humba', '250', '65', 'Pork', 'pork'),
('2', 'Pork Barbecue', '100', '50', 'barbecue', 'pork'),
('3', 'Sinubang Baboy', '100', '84', 'Sinugba', 'pork'),
('4', 'Calderetang Baboy', '150', '92', 'cald', 'pork'),
('5', 'Pork With Vagetables', '100', '198', 'prkwthv', 'pork');

-- --------------------------------------------------------

--
-- Table structure for table `rice`
--

CREATE TABLE `rice` (
  `id` varchar(100) NOT NULL,
  `FoodName` varchar(100) DEFAULT NULL,
  `Price` varchar(100) DEFAULT NULL,
  `Quantity` varchar(100) NOT NULL,
  `picturename` varchar(100) DEFAULT NULL,
  `Table` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rice`
--

INSERT INTO `rice` (`id`, `FoodName`, `Price`, `Quantity`, `picturename`, `Table`) VALUES
('1', 'Ganador', '30', '635', 'Ganador', 'rice'),
('2', 'Garlic Rice', '30', '13', 'Ricegarlic', 'rice'),
('3', 'Fried Rice', '50', '55', 'Fried', 'rice');

-- --------------------------------------------------------

--
-- Table structure for table `salesincome`
--

CREATE TABLE `salesincome` (
  `Customers` int(100) NOT NULL,
  `Payment` varchar(100) DEFAULT NULL,
  `cash` varchar(100) DEFAULT NULL,
  `change` varchar(100) DEFAULT NULL,
  `DateOfPurchase` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salesincome`
--

INSERT INTO `salesincome` (`Customers`, `Payment`, `cash`, `change`, `DateOfPurchase`) VALUES
(126, '310', '500', '190', '3/28/2017 9:42:37 AM'),
(127, '980', '1000', '110', '3/28/2017 10:29:40 AM');

-- --------------------------------------------------------

--
-- Table structure for table `seafood`
--

CREATE TABLE `seafood` (
  `id` varchar(100) NOT NULL,
  `FoodName` varchar(100) DEFAULT NULL,
  `Price` varchar(100) DEFAULT NULL,
  `Quantity` varchar(100) DEFAULT NULL,
  `picturename` varchar(100) DEFAULT NULL,
  `Table` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seafood`
--

INSERT INTO `seafood` (`id`, `FoodName`, `Price`, `Quantity`, `picturename`, `Table`) VALUES
('1', 'Fried Shrimp ', '250', '54', 'pasayan', 'seafood'),
('2', 'Garlic Shrimp', '300', '42', 'garlic', 'seafood'),
('3', 'Crab with milk', '100', '81', 'kasag', 'seafood'),
('4', 'Sinigang Bangus', '150', '87', 'bangus', 'seafood'),
('5', 'Sinugbang Bangus', '100', '80', 'sinugbabangus', 'seafood'),
('6', 'shells', '85', '21', 'shells', 'seafood');

-- --------------------------------------------------------

--
-- Table structure for table `sssss`
--

CREATE TABLE `sssss` (
  `Days` int(100) NOT NULL,
  `Cash` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sssss`
--

INSERT INTO `sssss` (`Days`, `Cash`, `date`) VALUES
(1, '200', '455465'),
(2, '200', '3/28/2017 7:54:19 AM'),
(3, '400', '3/28/2017 7:59:12 AM');

-- --------------------------------------------------------

--
-- Table structure for table `vagetables`
--

CREATE TABLE `vagetables` (
  `id` varchar(100) NOT NULL,
  `FoodName` varchar(100) DEFAULT NULL,
  `Price` varchar(100) DEFAULT NULL,
  `Quantity` varchar(100) DEFAULT NULL,
  `picturename` varchar(100) DEFAULT NULL,
  `Table` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vagetables`
--

INSERT INTO `vagetables` (`id`, `FoodName`, `Price`, `Quantity`, `picturename`, `Table`) VALUES
('1', 'Mongo', '50', '735', 'mongos', 'vagetables'),
('2', 'Vagetables Salad', '300', '55', 'salad', 'vagetables'),
('3', 'Ginataang Gulay', '100', '85', 'gata', 'vagetables'),
('4', 'Pinakbet', '150', '92', 'Pinakbet', 'vagetables'),
('5', 'Seven Season', '100', '83', 'seven', 'vagetables'),
('6', 'Chinese Pichay', '85', '30', 'Chinese', 'vagetables');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminmessage`
--
ALTER TABLE `adminmessage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adminss`
--
ALTER TABLE `adminss`
  ADD PRIMARY KEY (`user`);

--
-- Indexes for table `beef`
--
ALTER TABLE `beef`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cashier`
--
ALTER TABLE `cashier`
  ADD PRIMARY KEY (`user`);

--
-- Indexes for table `cashierinfo`
--
ALTER TABLE `cashierinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cashiermessage`
--
ALTER TABLE `cashiermessage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chicken`
--
ALTER TABLE `chicken`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `desert`
--
ALTER TABLE `desert`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `drinks`
--
ALTER TABLE `drinks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `foodname`
--
ALTER TABLE `foodname`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderss`
--
ALTER TABLE `orderss`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pork`
--
ALTER TABLE `pork`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rice`
--
ALTER TABLE `rice`
  ADD PRIMARY KEY (`id`,`Quantity`);

--
-- Indexes for table `salesincome`
--
ALTER TABLE `salesincome`
  ADD PRIMARY KEY (`Customers`);

--
-- Indexes for table `seafood`
--
ALTER TABLE `seafood`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sssss`
--
ALTER TABLE `sssss`
  ADD PRIMARY KEY (`Days`);

--
-- Indexes for table `vagetables`
--
ALTER TABLE `vagetables`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminmessage`
--
ALTER TABLE `adminmessage`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `cashiermessage`
--
ALTER TABLE `cashiermessage`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `orderss`
--
ALTER TABLE `orderss`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `salesincome`
--
ALTER TABLE `salesincome`
  MODIFY `Customers` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;
--
-- AUTO_INCREMENT for table `sssss`
--
ALTER TABLE `sssss`
  MODIFY `Days` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
